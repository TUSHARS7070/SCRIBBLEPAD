from distutils import text_file
from email.errors import InvalidMultipartContentTransferEncodingDefect
from email.iterators import body_line_iterator
from socket import SIO_KEEPALIVE_VALS
from tkinter import*
from tkinter import filedialog
from tkinter import font
from turtle import color, position, window_height
from tkinter import colorchooser
import os, sys
import pyttsx3
from doodle import Paint
from textblob import TextBlob


root = Tk()
root.title('ScribblePad')
root.iconbitmap('')
root.geometry("1200x720")

#Set variable for open file name
global open_status_name
open_status_name= False

global selected
selected=False

#Create a New File Funtion
def new_file():
    #Delete Previous Text
    my_text.delete("1.0", END)
    #Update Status bar
    root.title('New File - ScribblePad')
    status_bar.config(text="New File     ")

    global open_status_name
    open_status_name= False

#Create Open File function
def open_file():
    #Delete Previous Text
    my_text.delete("1.0", END)

    #Grab File Name
    text_file=filedialog.askopenfilename(title="Open File", filetypes=(("TEXT FILES", "*.txt"), ("HTML FILES", "*.html"), ("PYTHON FILES","*.py"),("ALL FILES","*.*")))
    
    if text_file:
        #Make file name global so we can access it later
        global open_status_name
        open_status_name= text_file
    
    #Update Status Bars
    name = text_file
    status_bar.config(text=f'{name}        ')
    name=name.replace("C:/Users/","")
    root.title(f'{name} - ScribblePad!')

    #Open the file
    text_file = open(text_file,'r')
    stuff = text_file.read()
    #Add file to textbox
    my_text.insert(END, stuff)
    #Close the opened file
    text_file.close()

#Save As File Function
def save_as_file():
    text_file=filedialog.asksaveasfilename(defaultextension=".*",title="Save File", filetypes=(("TEXT FILES","*.txt"),("HTML FILES","*.html"),("PYTHON FILES""*.py"),("ALL FILES","*.*")))
    if text_file:
        #Update Status bars
        name =text_file
        status_bar.config(text=f'Saved: {name}        ')
        name= name.replace("C:/Users/","")
        root.title(f'{name} - ScribblePad!')

        #Save the file
        text_file=open(text_file,'w')
        text_file.write(my_text.get(1.0,END))
        #Close the file
        text_file.close()

#Save file
def save_file():
    global open_status_name
    if open_status_name:
        #Save the file
        text_file=open(open_status_name,'w')
        text_file.write(my_text.get(1.0,END))
        #Close the file
        text_file.close()

        #Status update or Pop up code
        status_bar.config(text=f'Saved: {open_status_name}        ')
    else:
        save_as_file()

# Cut text
def cut_text(e):
    global selected
    #Check to see if keyboard SHortcut used
    if e:
        selected =root.clipboard_get()
    else:
        if my_text.selection_get():
            #Grab Selected text from text box
            selected=my_text.selection_get()
            #Delete text from text box
            my_text.delete("sel.first","sel.last")
            #Clear the clipboard then append 
            root.clipboard_clear()
            root.clipboard_append(selected)


# Copy text
def copy_text(e):
    global selected
    #Check to see if we use keyboard short-cuts
    if e:
        selected = root.clipboard_get()

    if my_text.selection_get():
         #Grab Selected text from text box
        selected=my_text.selection_get()
        #Clear the clipboard then append 
        root.clipboard_clear()
        root.clipboard_append(selected)

# Paste text
def paste_text(e):
    global selected
    #Check to see if keyboard shortcut used
    if e:
        selected=root.clipboard_get()
    else:
        if selected:
            position=my_text.index(INSERT)
            my_text.insert(position, selected)

#Bold Fucntions
def bold_it():
    #Create our font
    bold_font=font.Font(my_text, my_text.cget("font"))
    bold_font.configure(weight="bold")

    #Configure a tag
    my_text.tag_configure("bold", font=bold_font)

    #Define current_tags
    current_tags=my_text.tag_names("sel.first")

    #If statement to see if the tag has been set yet
    if "bold" in current_tags:
        my_text.tag_remove("bold", "sel.first", "sel.last")
    else:
        my_text.tag_add("bold", "sel.first", "sel.last")

#Italics Function
def italics_it():
    #Create our font
    italics_font=font.Font(my_text, my_text.cget("font"))
    italics_font.configure(slant="italic")

    #Configure a tag
    my_text.tag_configure("italic", font=italics_font)

    #Define current_tags
    current_tags=my_text.tag_names("sel.first")

    #If statement to see if the tag has been set yet
    if "italic" in current_tags:
        my_text.tag_remove("italic", "sel.first", "sel.last")
    else:
        my_text.tag_add("italic", "sel.first", "sel.last")


#Change selected text color
def text_color():
    #Pick a color
    my_color=colorchooser.askcolor()[1]
    if my_color:
        #Create our font
        color_font=font.Font(my_text, my_text.cget("font"))

        #Configure a tag
        my_text.tag_configure("colored", font=color_font, foreground=my_color)

        #Define current_tags
        current_tags=my_text.tag_names("sel.first")

        #If statement to see if the tag has been set yet
        if "colored" in current_tags:
            my_text.tag_remove("colored", "sel.first", "sel.last")
        else:
            my_text.tag_add("colored", "sel.first", "sel.last")

#Change BG Color
def bg_color():
    my_color=colorchooser.askcolor()[1]
    if my_color:
        my_text.config(bg=my_color)

#Change all text color
def all_text_color():
    my_color=colorchooser.askcolor()[1]
    if my_color:
        my_text.config(fg=my_color)

#Select All function
def select_all(e):
    #Add sel tag to select all text
    my_text.tag_add('sel', '1.0', END)

#Clear all function
def clear_all():
    #Add clear all
    my_text.delete(1.0, END)

#Text to Speech
def talk():
    engine = pyttsx3.init()
    engine.setProperty('rate', 175)
    voices = engine.getProperty('voices')
    engine.setProperty('voice', voices[1].id)
    engine.say(my_text.selection_get())
    engine.runAndWait()

def talk_all():
    engine = pyttsx3.init()
    engine.setProperty('rate', 175)
    engine.say(my_text.get(1.0, END))
    engine.runAndWait()

def check_spellscreen():
    root2 = Tk()
    root2.title('ScribblePad')
    root2.iconbitmap('')
    root2.geometry("1200x700")

    all = TextBlob(my_text.get(1.0, END))
    spell = Label(root2, text="Correct spelling is : ")
    spell.pack()
    correct = Label(root2, text=str(all.correct()))
    correct.pack()

#Create a toolbar frame
tb_frame=Frame(root)
tb_frame.pack(fill=X)

#Create main frame
my_frame = Frame(root)
my_frame.pack(pady=5)


#Create Scroll bar 
text_scroll = Scrollbar(my_frame)
text_scroll.pack(side=RIGHT, fill=Y)

#Create Horizontal Scroll bar 
hor_scroll = Scrollbar(my_frame, orient="horizontal")
hor_scroll.pack(side=BOTTOM, fill=X)

#Create Text box
my_text = Text(my_frame,width=97, height=25, font=("Helvetica", 16), selectbackground="yellow", selectforeground="black", undo=True, yscrollcommand=text_scroll.set, xscrollcommand=hor_scroll.set, wrap="none")
my_text.pack()

#Configure Scrollbar
text_scroll.config(command=my_text.yview)
hor_scroll.config(command=my_text.xview)

#Create menu
my_menu = Menu(root)
root.config(menu=my_menu)

#Add file Menu
file_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="File", menu=file_menu)
file_menu.add_command(label="New", command=new_file)
file_menu.add_command(label="Open", command=open_file)
file_menu.add_command(label="Save", command=save_file)
file_menu.add_command(label="Save As", command=save_as_file)
file_menu.add_separator()
file_menu.add_command(label="Exit", command=root.quit)

#Add Edit Menu
edit_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="Edit", menu=edit_menu)
edit_menu.add_command(label="Cut", command=lambda: cut_text(False), accelerator="Ctrl+x")
edit_menu.add_command(label="Copy", command=lambda: copy_text(False), accelerator="Ctrl+c")
edit_menu.add_command(label="Paste             ", command=lambda: paste_text(False),accelerator="Ctrl+v")
edit_menu.add_command(label="Undo", command=my_text.edit_undo, accelerator="Ctrl+z")
edit_menu.add_separator()
edit_menu.add_command(label="Redo", command=my_text.edit_redo, accelerator="Ctrl+y")
edit_menu.add_separator()
edit_menu.add_command(label="Select All", command=lambda: select_all(True), accelerator="Ctrl+a")
edit_menu.add_command(label="Clear", command=clear_all, accelerator="Ctrl+y")

#Add color Menu
color_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="Colors", menu=color_menu)
color_menu.add_command(label="Selected Text", command=text_color)
color_menu.add_command(label="All Text", command=all_text_color)
color_menu.add_command(label="Background", command=bg_color)

#Add Others Menu
other_menu = Menu(my_menu, tearoff=False)
my_menu.add_cascade(label="Others", menu=other_menu)
other_menu.add_command(label="Spell Check", command=check_spellscreen)
other_menu.add_command(label="Password Vault")

#Create Status Bar (Bottom)
status_bar = Label(root, text='Ready        ', anchor=E)
status_bar.pack(fill=X, side=BOTTOM, ipady=15)

#Edit Bindings
root.bind('<Control-Key-x>', cut_text)
root.bind('<Control-Key-c>', copy_text)
root.bind('<Control-Key-v>', paste_text)
#Select Bindings
root.bind('<Control-A>', select_all)
root.bind('<Control-a>', select_all)

#Create Buttons

#Bold Button
bold_button=Button(tb_frame, text="Bold", command=bold_it,fg='Black', activebackground='dark grey', border='5px', borderwidth='5px')
bold_button.grid(row=0, column=0, sticky=W, padx=5)

#Italics Button
italics_button=Button(tb_frame, text="Italics", command=italics_it,fg='Black', activebackground='dark grey', border='5px', borderwidth='5px')
italics_button.grid(row=0, column=1, padx=5)

#Text Color
color_text_button=Button(tb_frame, text="Text Color", command=text_color,fg='Black', activebackground='green', border='5px', borderwidth='5px')
color_text_button.grid(row=0, column=2, padx=5)

speech_button = Button(tb_frame, text="SPEAK", command=talk,fg='Black', activebackground='light green', border='5px', borderwidth='5px')
speech_button.grid(row=0, column=3, padx=10)

speech_button = Button(tb_frame, text="SPEAK ALL", command=talk_all,fg='Black', activebackground='light green', border='5px', borderwidth='5px')
speech_button.grid(row=0, column=4, padx=5)

doodle_button = Button(tb_frame, text="Canvas", command=Paint, fg='Black', activebackground='light pink', border='5px', borderwidth='5px')
doodle_button.grid(row=0, column=5, padx=10)
#R: 184 G: 254 B: 227


root.mainloop()